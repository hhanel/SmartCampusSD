package SOAP;


import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(serviceName = "Server", targetNamespace = "http://my.org/ns/")
public class Server {
     MongoConexao mongoConexao = new MongoConexao();

    /**
     * This is a sample web service operation
     */
     @WebMethod
     public boolean addSensor(String sensor) {
        if (!sensor.equals(null)) {
            return !mongoConexao.inserirDocumentoNaColecaoSensor(sensor).isEmpty();
            
        } else {
            return false;
        }
    }
   

    @WebMethod
    public String deleteSensor(Integer id) {
        if (!id.equals(null)) {
            return mongoConexao.removerDocumentoDaColecaoSensor(id);
        } else {
            return null;
        }
    }

    @WebMethod
    public String[] getSensor(String id) {
        if (!id.equals(null) & !id.isEmpty()) {
            return mongoConexao.coletarDocumentoNaColecaoSensor(id, 1, 1, 1, 1);
        } else {
            return null;
        }
    }

    @WebMethod
    public ArrayList<String[]> getAllSensors() {
        return mongoConexao.mostrarTodosDocumentosDaColecaoSensor();
    }

    @WebMethod
    public String addTipoSensor(String tpSensor) {
        if (!tpSensor.equals(null)) {
            return mongoConexao.inserirDocumentoNaColecaoTipoSensor(tpSensor);
        } else {
            return null;
        }
    }

    @WebMethod
    public String deleteTipoSensor(Integer id) {
        if (!id.equals(null)) {
            return mongoConexao.removerDocumentoDaColecaoTipoSensor(id);
        } else {
            return null;
        }
    }

    @WebMethod
    public String[] getTipoSensor(String id) {
        if (!id.equals(null) & !id.isEmpty()) {
            return mongoConexao.coletarDocumentoNaColecaoTipoSensor(id, 1, 1, 1, 1, 1);
        } else {
            return null;
        }
    }

    @WebMethod
    public ArrayList<String[]> getAllTipoSensors() {
        return mongoConexao.mostrarTodosDocumentosDaColecaoTipoSensor();
    }
    
}
