# pip install pymongo
# pip install python-dateutil

from pymongo import MongoClient
from datetime import datetime
from decimal import Decimal
import dateutil

def conectarMongoDB():
	conexao = MongoClient('localhost', 27017)
	return conexao

# Tipo Sensor -------------------------------------------------------------------------------------------

def coletarTiposSensores():
	conexao = conectarMongoDB()	
	tipoSensoresColetados = conexao.SmartCampusSensores.TipoSensor.find({ })
	if (tipoSensoresColetados.count() > 0):
		listaTipoSensoresColetados = []
		for tipoSensor in tipoSensoresColetados:
			listaTipoSensoresColetados.append(tipoSensor)
		return listaTipoSensoresColetados
	else:
		return "Nenhum Tipo Sensor Encontrado"


def coletarTipoSensorPeloID(ID):
	conexao = conectarMongoDB()	
	documentoEncontrado = conexao.SmartCampusSensores.TipoSensor.find({"_id": ID} , {"_id":True, "Comunica":True, "Minimo":True, "Maximo":True, "Intervalo":True })
	if (documentoEncontrado.count() > 0):
		return documentoEncontrado.next()
	else :
		return "Nenhum Tipo Sensor Encontrado Com ID " + str(ID)


def coletarOsIntervalosDosTiposSensores():
	conexao = conectarMongoDB()	
	intervalosSensoresColetados = conexao.SmartCampusSensores.TipoSensor.find({} , {"_id":True, "Minimo":True, "Maximo":True, "Intervalo":True }).sort([("_id", 1)])
	if (intervalosSensoresColetados.count() > 0):
		listaIntervalosSensores = []
		for intervalo in intervalosSensoresColetados:
			listaIntervalosSensores.append(intervalo)
		return listaIntervalosSensores
	else :
		return "Nenhum Dado Sobre Intervalo Encontrado"


def coletarIntervaloDoTiposSensorPeloID(ID):
	conexao = conectarMongoDB()	
	documentoEncontrado = conexao.SmartCampusSensores.TipoSensor.find({"_id": ID} , {"_id":False, "Minimo":True, "Maximo":True, "Intervalo":True })
	if (documentoEncontrado.count() > 0):
		return documentoEncontrado.next()
	else :
		return "Nenhum Intervalo No Tipo Sensor Encontrado Com ID " + str(ID)


def coletarComunicacoesDosTiposSensores():
	conexao = conectarMongoDB()	
	comunicacoes = conexao.SmartCampusSensores.TipoSensor.distinct("Comunica")
	comunicacoes.sort()
	return (comunicacoes if len(comunicacoes) > 0 else "Nenhuma Comunicação Encontrada Em Tipo De Sensor")


def coletarComunicacaoDoTipoSensorePeloIdOuTipo(IdOuTipo):
	conexao = conectarMongoDB()	
	if IdOuTipo.isdigit():
		comunicacao = conexao.SmartCampusSensores.TipoSensor.find({"_id": int(IdOuTipo)} , {"_id":False, "Comunica":True}).sort([("_id", 1)])
		if (comunicacao.count() > 0):
			return comunicacao.next()
		else :
			return "Nenhuma Comunicação Encontrada Em Tipo Sensor Com ID " + str(IdOuTipo)
	else:
		comunicacoes = conexao.SmartCampusSensores.TipoSensor.find({"Comunica": IdOuTipo.upper()} , {"_id":True, "Comunica":True}).sort([("_id", 1)])
		if (comunicacoes.count() > 0):
			listaComunicacoes = []
			for comunicacao in comunicacoes:
				listaComunicacoes.append(comunicacao)
			return listaComunicacoes
		else :
			return "Nenhuma Comunicacao Do Tipo " + str(IdOuTipo) + " Encontrada Em Tipo Sensor"

# Sensor ------------------------------------------------------------------------------------------------

def coletarOsIdsDosSensores():
	conexao = conectarMongoDB()	
	sensoresColetados = conexao.SmartCampusSensores.Sensor.find({ })
	if (sensoresColetados.count() > 0):
		listaSensoresColetados = []
		for sensor in sensoresColetados:
			listaSensoresColetados.append(sensor)
		return listaSensoresColetados
	else:
		return "Nenhum Sensor Encontrado"


def coletarSensorPeloID(ID):

	conexao = conectarMongoDB()	
	idTipoSensor = {"_idTipo" : ""}
	novoJsonn = {"Comunica" : ""}
	listaDado = []

	documentosEncontradosSensor = conexao.SmartCampusSensores.Sensor.find({"_id": ID})
	if (documentosEncontradosSensor.count() > 0):
		idTipoSensor.update({"_idTipo":documentosEncontradosSensor.next()['Tipo']})
		documentosEncontradoTipoSensor = conexao.SmartCampusSensores.TipoSensor.find({"_id": idTipoSensor['_idTipo']})
		dadosTipoSensor = documentosEncontradoTipoSensor.next()
		novoJsonn.update({"_idSensor" : ID})
		novoJsonn.update({"_idTipo" : dadosTipoSensor['_id']})
		novoJsonn.update({"Comunica" : dadosTipoSensor['Comunica']})
		novoJsonn.update({"Minimo" : dadosTipoSensor['Minimo']})
		novoJsonn.update({"Maximo" : dadosTipoSensor['Maximo']})		
		novoJsonn.update({"Intervalo" : dadosTipoSensor['Intervalo']})
		listaDado.append(novoJsonn)	
		return listaDado
	else :
		return "Nenhum Sensor Encontrado Com ID " + str(ID)


def coletarOsTiposDosSensores():
	conexao = conectarMongoDB()	
	tiposSensoresColetados = conexao.SmartCampusSensores.Sensor.distinct("Tipo")
	tiposSensoresColetados.sort()
	return (tiposSensoresColetados if len(tiposSensoresColetados) > 0 else "Nenhum Tipo De Sensor Encontrado")


def coletarSensorPeloTipo(Tipo):
	conexao = conectarMongoDB()	
	documentosEncontrados = conexao.SmartCampusSensores.Sensor.find({"Tipo": Tipo} , {"_id":True, "Descricao":True, "Latitude":True, "Longitude":True }).sort([("_id", 1)])
	if (documentosEncontrados.count() > 0):
		listaDocumentosEncontrados = []
		for documento in documentosEncontrados:
			listaDocumentosEncontrados.append(documento)
		return listaDocumentosEncontrados
	else :
		return "Nenhum Sensor " + Tipo + " Encontrado"


def coletarAsLatLonDosSensores():
	conexao = conectarMongoDB()	
	latLonSensoresColetados = conexao.SmartCampusSensores.Sensor.find({} , {"_id":True, "Latitude":True, "Longitude":True }).sort([("_id", 1)])
	if (latLonSensoresColetados.count() > 0):
		listaLatLonSensoresColetados = []
		for latLon in latLonSensoresColetados:
			listaLatLonSensoresColetados.append(latLon)
		return listaLatLonSensoresColetados
	else :
		return "Nenhum Dado Sobre Latitude e Longitude Encontrado"


def coletarLatLonDoSensorPeloID(ID):
	conexao = conectarMongoDB()	
	latLonSensoresColetados = conexao.SmartCampusSensores.Sensor.find({"_id":ID} , {"_id":False, "Latitude":True, "Longitude":True })
	if (latLonSensoresColetados.count() > 0):
		return latLonSensoresColetados.next()
	else :
		return "Nenhum Dado Sobre Latitude e Longitude Encontrado Para o ID " + str(ID)

# Dados -------------------------------------------------------------------------------------------------

def coletarTodosDados():
	conexao = conectarMongoDB()
	dados = conexao.SmartCampusSensores.Dados.find({}, { "ID":True, "Valor":True, "Data":True, "Hora":True })
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			dado['_id'] = str(dado['_id'])
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado"


def coletarDadosPeloID(ID):
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"ID": ID} , {"_id":False, "Valor":True, "Data":True, "Hora":True })
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Para Sensor De ID " + str(ID)


def coletarUltimoDadoCadaSensor():
	conexao = conectarMongoDB()
	ultimosDados = conexao.SmartCampusSensores.Dados.aggregate([{"$sort":{"ID":1,"Data":1,"Hora":1}},{"$group":{"_id": "$ID","ultimoDado":{"$last":"$Valor"}}}])
	listaUltimosDados = []
	for ultimoDado in ultimosDados:
		listaUltimosDados.append(ultimoDado)
	return listaUltimosDados


def coletarDadosDesdeUmaData(data):
	dataFormatada = datetime.strptime(data, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataFormatada.year, dataFormatada.month, dataFormatada.day) } } , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True}).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Desde " + str(dataFormatada)


def coletarDadosDesdeUmaDataPeloID(data, ID):
	dataFormatada = datetime.strptime(data, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataFormatada.year, dataFormatada.month, dataFormatada.day) },"ID": ID} , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True}).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Para o Sensor De ID " + str(ID) + " Desde " + str(dataFormatada)


def coletarDadosDesdeUmaDataHora(data, hora):
	dataFormatada = datetime.strptime(data, "%Y%m%d")
	conexao = conectarMongoDB()
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataFormatada.year, dataFormatada.month, dataFormatada.day)}, "Hora" : {"$gte":hora}} , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True }).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Para Desde " + str(dataFormatada) + " As " + hora


def coletarDadosDesdeUmaDataHoraPeloID(data, hora, ID):
	dataFormatada = datetime.strptime(data, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataFormatada.year, dataFormatada.month, dataFormatada.day) }, "Hora" : {"$gte":hora} ,"ID": ID} , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True }).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado o Sensor De ID " + str(ID) + " Desde " + str(dataFormatada) + " As " + hora


def coletarDadosDesdeUmaDataAteOutra(dataInicial, dataFinal):
	dataInicialFormatada = datetime.strptime(dataInicial, "%Y%m%d")
	dataFinalFormatada = datetime.strptime(dataFinal, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataInicialFormatada.year, dataInicialFormatada.month, dataInicialFormatada.day), "$lte" : datetime(dataFinalFormatada.year, dataFinalFormatada.month, dataFinalFormatada.day) } } , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True}).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		for dado in dados:
			listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Desde " + str(dataInicialFormatada) + " Ate " + str(dataFinalFormatada) 


def coletarDadosDesdeUmaDataHoraAteOutra(dataInicial, horaInicial, dataFinal, horaFinal):
	dataInicialFormatada = datetime.strptime(dataInicial, "%Y%m%d")
	dataFinalFormatada = datetime.strptime(dataFinal, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataInicialFormatada.year, dataInicialFormatada.month, dataInicialFormatada.day) }, "Hora" : {"$gte":horaInicial}} , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True }).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	if (dados.count() > 0):
		listaDados = []
		dataPesquisa = datetime(dataFinalFormatada.year, dataFinalFormatada.month, dataFinalFormatada.day)
		for dado in dados:
			if ( (dado['Data']<=dataPesquisa) and (dado['Hora']<= horaFinal ) ):
				listaDados.append(dado)
		return listaDados
	else :
		return "Nenhum Dado Encontrado Desde " + str(dataInicialFormatada) + " Ate " + str(dataFinalFormatada)

 
def coletarDadosDesdeUmaDataHoraAteOutraPeloId(dataInicial, horaInicial, dataFinal, horaFinal, ID):
	dataInicialFormatada = datetime.strptime(dataInicial, "%Y%m%d")
	dataFinalFormatada = datetime.strptime(dataFinal, "%Y%m%d")
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.find({"Data": {"$gte" : datetime(dataInicialFormatada.year, dataInicialFormatada.month, dataInicialFormatada.day) }, "Hora" : {"$gte":horaInicial} ,"ID": ID} , {"_id":False, "ID":True, "Valor":True, "Data":True, "Hora":True }).sort([('Data', 1), ('Hora', 1), ('ID', 1)])
	listaDados = []
	dataPesquisa = datetime(dataFinalFormatada.year, dataFinalFormatada.month, dataFinalFormatada.day)
	for dado in dados:
		if ( (dado['Data']<=dataPesquisa) and (dado['Hora']<= horaFinal ) ):
			listaDados.append(dado)
	if (len(listaDados) > 0):
		return listaDados
	else :
		return "Nenhum Dado Encontrado Desde " + str(dataInicialFormatada) + " Ate " + str(dataFinalFormatada)

# Medias  -------------------------------------------------------------------------------------------------

def coletarMediaDiariaCadaSensor():
	conexao = conectarMongoDB()	
	dados = conexao.SmartCampusSensores.Dados.aggregate([{"$group":{"_id": {"Data": "$Data", "ID": "$ID"},"Quantidade":{"$sum": 1}, "Somatorio": {"$sum":"$Valor"}}}])
	listaDados = []
	for dado in dados:
		dado.update({"Media": (dado['Somatorio']/dado['Quantidade'])})
		listaDados.append(dado)
	return listaDados


def coletarMediaDiariaCadaTipo():
	conexao = conectarMongoDB()
	colecaoDados = conexao.SmartCampusSensores.Dados.find({})
	if (colecaoDados.count()>0):
		listaDados = []
		for dado in colecaoDados:
			colecaoSensor = conexao.SmartCampusSensores.Sensor.find({"_id" : dado['ID']})
			dado.update({"Tipo":colecaoSensor.next()['Tipo']})
			dado['_id'] = str(dado['_id'])
			listaDados.append(dado)
		tipoPossiveis = conexao.SmartCampusSensores.TipoSensor.distinct("_id")
		novaLista = []
		for cadaTipo in tipoPossiveis:
			contagem = 0
			somatorio = 0
			novoDado = {"Tipo" : ""}
			for cadaDado in listaDados:
				print(cadaDado)
				if (cadaDado['Tipo']==cadaTipo):
					contagem = contagem + 1
					somatorio = somatorio + cadaDado['Valor']
			if (contagem > 0):
				novoDado.update({"Tipo" : cadaTipo})
				novoDado.update({"Somatorio" : somatorio})
				novoDado.update({"Quantidade" : contagem})		
				novoDado.update({"Media" : somatorio/contagem})
				novaLista.append(novoDado)	
		return novaLista
	else:
		return "Nenhum Dado Encontrado Na Colecao Dados"

# Post ----------------------------------------------------------------------------------------------------

def cadastrarNovoSensor(_id, Descricao, Latitude, Longitude, Tipo):
	conexao = conectarMongoDB()
	documentosSensor = conexao.SmartCampusSensores.Sensor.find({"_id" : int(_id)})
	if (documentosSensor.count()>0):
		return "O Identificador (" + _id + ") Ja Esta Cadastrado Na Colecao Sensor" 
	else:
		documentosTipoSensor = conexao.SmartCampusSensores.TipoSensor.find({"_id" : int(Tipo)})
		if (documentosTipoSensor.count()>0):
			novoDocumento = {"_id": int(_id), "Descricao" : Descricao, "Latitude":float(Latitude), "Longitude":float(Longitude), "Tipo":int(Tipo)}
			conexao.SmartCampusSensores.Sensor.insert_one(novoDocumento)
			return "Novo Sensor De ID (" + _id + ") Cadastrado Com Sucesso Na Colecao Sensor"
		else:
			return "O Tipo (" + Tipo + ") Nao Esta Cadastrado Na Colecao Tipo Sensor, Portanto, Nao e Um Tipo Valido"


def cadastrarNovoTipoSensor(_id, Descricao, Comunica, Minimo, Maximo, Intervalo):
	conexao = conectarMongoDB()
	documentosTipoSensor = conexao.SmartCampusSensores.TipoSensor.find({"_id" : int(_id)})
	if (documentosTipoSensor.count()>0):
		return "O Identificador (" + _id + ") Ja Esta Cadastrado Na Colecao Tipo Sensor" 
	else:
		if (Comunica.upper() == "UDP" or  Comunica.upper() == "TCP"):
			novoDocumento = {"_id": int(_id), "Descricao" : Descricao, "Comunica":Comunica, "Minimo":int(Minimo), "Maximo":int(Maximo), "Intervalo":int(Intervalo)}
			conexao.SmartCampusSensores.TipoSensor.insert_one(novoDocumento)
			return "Novo Tipo Sensor De ID (" + _id + ") Cadastrado Com Sucesso Na Colecao Tipo Sensor"
		else:
			return "A Comunicacao (" + Comunica + ") Nao e Valida Na Colecao Tipo Sensor, Precisa Ser TCP Ou UDP"