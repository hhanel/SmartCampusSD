# Digite no terminal:   python -m pip install flask
# Compilar projeto:     set FLASK_APP=SmartCampus_WebServiceRest.py
# Rodar projeto:        flask run


from flask import Flask, jsonify ,request
from MongoDB import *
app = Flask(__name__)


def jsonResposta(resposta):
    return jsonify({
        'Resposta': resposta
    })


@app.route("/")
def home():
	return jsonResposta("Sistemas Distribuídos - Smart Campus")

# Sensor ------------------------------------------------------------------------------------------------

@app.route("/sensor", methods=['GET'])
def getTheSensorsIds():
    return jsonResposta(coletarOsIdsDosSensores())


@app.route("/sensor/<int:ID>", methods=['GET'])
def getSensorById(ID):
    return jsonResposta(coletarSensorPeloID(ID))


@app.route("/sensor/type", methods=['GET'])
def getTheSensorsTypes():
    return jsonResposta(coletarOsTiposDosSensores())


@app.route("/sensor/type/<string:Tipo>", methods=['GET'])
def getSensorByType(Tipo):
    return jsonResposta(coletarSensorPeloTipo(Tipo))


@app.route("/sensor/latlon", methods=['GET'])
def getTheSensorsLatLon():
    return jsonResposta(coletarAsLatLonDosSensores())


@app.route("/sensor/latlon/<int:ID>", methods=['GET'])
def getTheSensorLatLonById(ID):
    return jsonResposta(coletarLatLonDoSensorPeloID(ID))

# Type Sensor -------------------------------------------------------------------------------------------

@app.route("/sensortype", methods=['GET'])
def getTheSensorsTypesIds():
    return jsonResposta(coletarTiposSensores())


@app.route("/sensortype/<int:ID>", methods=['GET'])
def getSensorTypeById(ID):
    return jsonResposta(coletarTipoSensorPeloID(ID))


@app.route("/sensortype/range", methods=['GET'])
def getTheSensorsTypesRanges():
    return jsonResposta(coletarOsIntervalosDosTiposSensores())


@app.route("/sensortype/range/<int:ID>", methods=['GET'])
def getTheSensorTypeRangeById(ID):
    return jsonResposta(coletarIntervaloDoTiposSensorPeloID(ID))


@app.route("/sensortype/communicate", methods=['GET'])
def getTheSensorsTypesCommunications():
    return jsonResposta(coletarComunicacoesDosTiposSensores())


@app.route("/sensortype/communicate/<string:IdOuTipo>", methods=['GET'])
def getTheSensorsTypesCommunicationsByIdOrType(IdOuTipo):
    return jsonResposta(coletarComunicacaoDoTipoSensorePeloIdOuTipo(IdOuTipo))

# Dadas -------------------------------------------------------------------------------------------------

@app.route("/data", methods=['GET'])
def getAllData():
    return jsonResposta(coletarTodosDados())


@app.route("/data/<int:ID>", methods=['GET'])
def getDataById(ID):
    return jsonResposta(coletarDadosPeloID(ID))


@app.route("/data/latest", methods=['GET'])
def getLastDataEachSensor():
    return jsonResposta(coletarUltimoDadoCadaSensor())


@app.route("/data/since/<string:data>", methods=['GET'])
def getDataSinceDate(data):
    return jsonResposta((coletarDadosDesdeUmaData(data)))


@app.route("/data/since/<string:data>/byid/<int:ID>", methods=['GET'])
def getDataSinceDateByID(data, ID):
    return jsonResposta((coletarDadosDesdeUmaDataPeloID(data, ID)))


@app.route("/data/since/<string:data>/at/<string:hora>", methods=['GET'])
def getDataSinceDateAtHour(data, hora):
    return jsonResposta((coletarDadosDesdeUmaDataHora(data, hora)))


@app.route("/data/since/<string:data>/at/<string:hora>/byid/<int:ID>", methods=['GET'])
def getDataSinceDateHourByID(data, hora, ID):
    return jsonResposta((coletarDadosDesdeUmaDataHoraPeloID(data, hora, ID)))


@app.route("/data/since/<string:dataInicial>/until/<string:dataFinal>", methods=['GET'])
def getDataSinceDateUntilDate(dataInicial, dataFinal):
    return jsonResposta((coletarDadosDesdeUmaDataAteOutra(dataInicial, dataFinal)))


@app.route("/data/since/<string:dataInicial>/at/<string:horaInicial>/until/<string:dataFinal>/at/<string:horaFinal>", methods=['GET'])
def getDataSinceDateAtHourUntilDateArHour(dataInicial, horaInicial, dataFinal, horaFinal):
    return jsonResposta((coletarDadosDesdeUmaDataHoraAteOutra(dataInicial, horaInicial, dataFinal, horaFinal)))


@app.route("/data/since/<string:dataInicial>/at/<string:horaInicial>/until/<string:dataFinal>/at/<string:horaFinal>/byid/<int:ID>", methods=['GET'])
def getDataSinceDateAtHourUntilDateArHourById(dataInicial, horaInicial, dataFinal, horaFinal, ID):
    return jsonResposta((coletarDadosDesdeUmaDataHoraAteOutraPeloId(dataInicial, horaInicial, dataFinal, horaFinal, ID)))

# Avarege ------------------------------------------------------------------------------------------------


@app.route("/avarege/dialy/sensor", methods=['GET'])
def getAvaregeDailyEachSensor():
    return jsonResposta(coletarMediaDiariaCadaSensor())


@app.route("/avarege/dialy/type", methods=['GET'])
def getAvaregeDailyEachType():
    return jsonResposta(coletarMediaDiariaCadaTipo())


# PUT ---------------------------------------------------------------------------------------------------

@app.route("/sensor", methods=['POST'])
def registerNewSensor():    
    return jsonResposta(cadastrarNovoSensor(request.form['_id'], request.form['Descricao'], request.form['Latitude'], request.form['Longitude'], request.form['Tipo'] ))


@app.route("/sensortype", methods=['POST'])
def registerNewSensorType():
    return jsonResposta(cadastrarNovoTipoSensor(request.form['_id'], request.form['Descricao'], request.form['Comunica'],request.form['Minimo'], request.form['Maximo'], request.form['Intervalo'] ))